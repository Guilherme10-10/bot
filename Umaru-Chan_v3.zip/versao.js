module.exports = client => {
	var versao = {
		v: "3.9.2"
	}
	client.once('ready', () => {
		console.log(`VERSAO: ${versao.v}`)
	})
}