const cor = require("chalk")
const firebase = require("firebase")
var cmd = console.log

var firebaseConfig = {
    apiKey: "AIzaSyCE_I5gdkDBE5rR0DaVGPkUR5PpYr8N8FA",
    authDomain: "umaru-chan-ab251.firebaseapp.com",
    databaseURL: "https://umaru-chan-ab251-default-rtdb.firebaseio.com",
    projectId: "umaru-chan-ab251",
    storageBucket: "umaru-chan-ab251.appspot.com",
    messagingSenderId: "778643704337",
    appId: "1:778643704337:web:076d23d49e91aa82e97fb0"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

cmd(cor.green('✓ [BANCO DE DADOS] : Ok'))