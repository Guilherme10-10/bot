
//const db = firebase.database();
const firebase = require("firebase")
//const db = firebase.database();
const log = console.log
const Discord = require("discord.js")
require("discord-reply")
/*const emotes = */require('discord-emotes')
const client = new Discord.Client({
	intents: new Discord.Intents(32767)
})
const config = require("./config.js")
const fs = require("fs")
require("./firebase.js")
const color = require("chalk")
//slash:
client.once('ready', async () => {

    console.log("🧡 - sucesso!")

})

module.exports = client;
client.commands = new Discord.Collection();
client.slashCommands = new Discord.Collection();
client.config = require("./config.js");
require("./handler")(client);
const { glob } = require("glob");
const { promisify } = require("util");

const globPromise = promisify(glob);

client.on("interactionCreate", async (interaction) => {

    if (!interaction.guild) return;
  
    if (interaction.isCommand()) {

        const cmd = client.slashCommands.get(interaction.commandName);

        if (!cmd)
            return;

        const args = [];

        for (let option of interaction.options.data) {

            if (option.type === "SUB_COMMAND") {
                if (option.name) args.push(option.name);
                option.options?.forEach((x) => {
                    if (x.value) args.push(x.value);
                });
            } else if (option.value) args.push(option.value);
        }

        cmd.run(client, interaction, args);
    }

    if (interaction.isContextMenu()) {
        await interaction.deferReply({ ephemeral: false });
        const command = client.slashCommands.get(interaction.commandName);
        if (command) command.run(client, interaction);
        
    }
});
			
//-------
const akinator = require("discord.js-akinator");

const language = "pt"; //The Language of the Game
const childMode = false; //Whether to use Akinator's Child Mode
const gameType = "character"; //The Type of Akinator Game to Play. ("animal", "character" or "object")
const useButtons = true; //Whether to use Discord's Buttons

client.on("messageCreate", async message => {
    if(message.content.startsWith(`${config.prefix}aki`)) {
        akinator(message, {
            language: language, //Defaults to "en"
            childMode: childMode, //Defaults to "false"
            gameType: gameType, //Defaults to "character"
            useButtons: useButtons //Defaults to "false"
        });
    }
});

const v = require("./versao")
v(client)

const express = require('express');
const app = express();

app.get("/api", (req, res) => {
  
	res.json({
	status: 102,
	api_status: "indisponível",
});

	
})

app.get("/", (request, response) => {

	response.status(403).send('Tudo ok')
	
	const ping = new Date();
  ping.setHours(ping.getHours() - 3);
  console.log(color.blue(`Ping as ${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()}`))
  //response.sendStatus(200);
});
app.listen(process.env.PORT)
 //teste

 const erros_logs = require('./error_logs')
erros_logs(client)//teste
client.once('ready', () => {
  console.log(client.user.tag)
});

//função de eventos em pasta:
fs.readdir("./events/", (err, files) => {
    if (err) return console.error(err);

    files.forEach((file) => {

        const Event = require(`./events/${file}`)

        let EventName = file.split(".")[0];

        client.on(EventName, Event.bind(null, client));

    });
})
//STATUS DO BOT UMARU-CHAN:
const status = require('./status.js')
status(client)

//menção do BoT UMARU-CHAN:
client.on("messageCreate", message => {
const Discord = require('discord.js')

var img = [//imagens para thumb da mensagem embed:
	
"https://imgur.com/IbSDQOV.png",
	
"https://imgur.com/JobCkOB.png",
	
"https://imgur.com/5J0dpYb.png"

];

var imgmenc = img[Math.floor(Math.random() * img.length)];// Embaralha as imagens para ficar com orden aleatória
	
	const mencaoembed = new Discord.MessageEmbed()

.setTitle(`<a:emoji_17:864082263326588959> | Alguém me mencionou ai?`)
.setDescription(`<:umaru_14:864078268152152074> **Ola __${message.author.username}__ tudo bem?, espero que sim.\n\nMeu prefixo e: \`${config.prefix}\`, use o comando \`${config.prefix}help\` para ver meus comandos e informações.**`)
//.setThumbnail(imgmenc)
.setImage('https://imgur.com/hJT1Tmc.png')
	.setFooter(`© Todos os direitos reservados á Guilhermewal - Umaru-Chan • 2022`, client.user.displayAvatarURL({ dynamic: false }))
	.setColor("ORANGE")
	
if(message.content == `<@${client.user.id}>` || message.content == `<@!${client.user.id}>`) {
    return		message.reply({ embeds: [mencaoembed] })
}

	  if (message.author.bot) return;
    if (message.channel.type == 'dm')		return;
	return;
})
	

//Conecta o bot no token
client.login(process.env.TOKEN)
