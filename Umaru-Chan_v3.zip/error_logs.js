
const color = require("chalk")

module.exports = client => {
process.on('multipleResolves', (type, reason, promise) => {
	
    console.log(color.red(`🆘  Erro no código:\n` + type, promise, reason))
});
	
process.on('unhandRejection', (reason, promise) => {
    console.log(color.yellow(`⚠️ Ops:\n` + reason, promise))
});
	
process.on('uncaughtException', (error, origin) => {
    console.log(color.yellow(`⚠️  Erros em geral:\n` + error, origin))
});
	
process.on('uncaughtExceptionMonitor', (error, origin) => {
    console.log(color.red(`🆘 Erro ai oh:\n` + error, origin))
}); 

}
