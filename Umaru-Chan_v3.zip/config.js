const config = {
"prefix": "u!"

	
}
module.exports = config;

