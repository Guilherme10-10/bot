module.exports = client => {
client.on("ready", () => {

	let activities = [
   
    //`${client.users.cache.size} 🥰 Usuarios`,
    
    `Servidores 🌐 ${client.guilds.cache.size}`,
    
    `🧡 Assistindo animes`,
  
    `🤖 Meu prefixo(u!)`,
		
    `u!help`,
    
    ];

    i = 0;
    setInterval(() => client.user.setActivity(`${activities[i++ %activities.length]}`, {
     //---------------------------------
      //PLAYING //STREAMING //LISTENING //WATCHING//
     //---------------------------------
     
      type: "PLAYING"
     
}), 3000); //←·tempo de mensagem//
//Tipos de status o bot.
//online
//idle
//dnd
//invisible
client.user.setStatus('idle')
});
}