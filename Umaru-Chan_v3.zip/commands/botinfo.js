const osu = require('node-os-utils')
var os = require('os');
const { MessageEmbed } = require('discord.js')

module.exports.run = async (client, message, args) => {

let ping = client.ws.ping;

        let embed_1 = new MessageEmbed()
        .setColor('ORANGE')
        .setDescription(`**💻 • Carregando informações...**`);
        
        
	
const info = osu.cpu
const cpu = (info.loadavgTime() / 2) * 10

var usedMemory = os.totalmem() -os.freemem(), totalMemory = os.totalmem();

var  getpercentage = 
  ((usedMemory/totalMemory) * 100).toFixed(2) + '%'

var memoria = (usedMemory/ Math.pow(1024, 3)).toFixed(2)
	



const embed_3 = new MessageEmbed()
.setTitle('BOT INFO')
.setColor('ORANGE')
.setDescription(`**🔸 | Ping:\`(${ping})ms\`\n\n📀 | Memória usada em GB:\`(${memoria})MB/GB\`\n\n🧭 | Memoria usada:\`(${getpercentage})%\`\n\n🙎 | Usuários: \`${client.users.cache.size}\`\n\n🌐 | Servidores:\`${client.guilds.cache.size}\`**`)
.setFooter(message.guild.name, message.guild.iconURL())
	.setTimestamp()

	let ping_cmd = await message.reply({ content: `${message.author}`, embeds: [embed_1] }).then(msg => {
            setTimeout( () => {
                msg.edit({ content: `${message.author}`, embeds: [embed_3] })
            }, 2000)
        })

}