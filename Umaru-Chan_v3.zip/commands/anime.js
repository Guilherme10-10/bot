
const malScraper = require("mal-scraper");
const translate = require("@iamtraction/google-translate");
const moment = require("moment");
const { MessageEmbed } = require("discord.js");

module.exports.run = async(client, message, args) => {
	{
    const search = args.join(" ");

    if (!search)
      return message.reply(
        `**${message.author}, insira o nome do anime que deseja pesquisar.**`
      );

    const data = await malScraper.getInfoFromName(search);

    const trad = await translate(data.synopsis, {
     to: "pt-BR".slice(0, 2),
    });

    const date = data.aired.split(" to ").map((x) => x.replace(",", ""));

    const ANIME = new MessageEmbed()
      .setColor("ORANGE")
			.setDescription(
        `**🎎 [${data.title}](${data.url})**\n${
          trad.text.length > 900 ? trad.text.slice(0, 900) + "..." : trad.text
        }`
      )
      .setThumbnail(data.picture)
			.setFooter(`${message.author.tag}`, message.author.displayAvatarURL())
.setTimestamp()
      .addFields(
        {
          name: `🔶 | Episódios:`,
          value: data.episodes.toLocaleString().replace("Unknown", "Em produção."),
          inline: true,
        },
        {
          name: `📺 | Tipo:`,
          value: data.type,
          inline: true,
        },
        {
          name: `🏆 | Rank:`,
          value: data.ranked,
          inline: true,
        },
        {
          name: `❤️ | Popularidade:`,
          value: data.popularity,
          inline: true,
        },
        {
          name: `💠 | Status:`,
          value: data.status
            .replace("Finished Airing", "Finalizado")
            .replace("Currently Airing", "Em produção."),
          inline: true,
        },
        {
          name: `💫 | Categoria's:`,
          value: data.source,
          inline: true,
        },
        {
          name: `🗓️ | Informações sobre Lançamento:`,
          value:
            date[1] == "?" || !date[1]
              ? `**${moment(new Date(date[0])).format("L")}**`
              : `**${moment(new Date(date[0])).format("L")}** - **${moment(
                  new Date(date[1])
                ).format("L")}**`,
          inline: true,
        },
        {
          name: `🕘 | Duração por Episódio:`,
          value: data.duration.replace(". per ep", ""),
          inline: true,
        },
        {
          name: `👌 | Gêneros:`,
          value: data.genres.map((x) => x).join(", "),
          inline: false,
        },
        {
          name: `⭐ | Avaliação:`,
          value: data.score,
          inline: true,
        }
      );
		 

    if (data.trailer != undefined)
      ANIME.addField(
        `🎬 | Trailer:`,
        `**[Clique Aqui](${data.trailer})**`,
        true
      );

    message.reply({ embeds:  [ANIME], content: `${message.author}` }).catch((error) => {
      console.log(error);
      return message.reply(`${message.author}, anime não encontrado.`);
    });
}
				}