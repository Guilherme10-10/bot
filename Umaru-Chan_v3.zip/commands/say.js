const Discord = require('discord.js')

module.exports = {

  config: {

    nome: 'repete',                                                   // NOTA: Coloque o nome do comando SEMPRE em letras minúsculas!
    aliases: ['falar'],                               // Alternativas para o comando, para você poder usar o comando com vários nomes diferentes.
     descricao: 'faz o bot fala algo',     // Descrição do comando (OPCIONAL, porém é útil para organização ou para um comando de ver a informação de outros comandos).
    utilizacao: '',                                               // Modo de utilização do comando. Deixe em branco, ou seja, apenas com '', caso o comando não precise de argumentos para ser usado (OPCIONAL, porém é útil para organização ou para um comando de ver a informação de outros comandos).
     cooldown: 3000                                        // 3 segundos de tempo de espera até o usuário poder executar o comando de novo. Caso o comando não tenha tempo de espera, pode remover esta linha ou colocar     cooldown: 0
  },
  run: async (client, message, args) => {
		
   
const embed = new Discord.MessageEmbed()
		.setColor("ORANGE")
.setDescription("**Escreva algo para eu repetir!**")
		
var repete = args.join(" ")
  //message.delete().catch(O_o => {});
    if(!repete) return message.reply
    ({ embeds: [embed]})
    message.channel.send(`${repete}\n\n• _Mensagem enviada por ${message.author}_`)
  }
			}