exports.run = async (client, message, args) => {
/*
 let name = ('Naruto Uzumaki');
 let user = message.author       

 let imagens = [
    "https://imgur.com/ss3nE63.png",
	 
	  "https://imgur.com/x1Pk0MJ.png"
 ]

 let imagem = imagens[Math.floor(Math.random() * imagens.length)]

 let avatar = {avatar: imagem}

 var naruto_f = [

		'**"Não é o rosto que faz de alguém um monstro, são as escolhas que elas fazem para as suas vidas."**',
		
		'**"Trabalho duro é inútil para aqueles que não acreditam em si mesmos."**',
		
		'**"Lar é onde tem alguém sempre pensando em você."**',
	  
		'**"Desista de me fazer desistir!"**',
	  
		'**"Se você não gosta do seu destino, não aceite. Em vez disso, tenha a coragem de mudá-lo do jeito que você quer que seja."**',
	  
		'**“O fracasso não é razão para você desistir, desde que continue acreditando.”**',
		
		'**"O que dói não é crescer. O que dói é ver uma pessoa que tanto amou mudar."**'
	];
	
	var naruto_frase = naruto_f[Math.floor(Math.random() * naruto_f.length)];

 message.channel.createWebhook(name, avatar).then(webhook => { 
 webhook.send(naruto_frase).then(() => webhook.delete())})
	*/
	message.reply('**Comando fora do ar.** [403]')
    }
	 