const Discord = require('discord.js')

exports.run = async (client, message, args, db) => {

if(!message.member.permissions.has('MANAGE_CHANNELS')) {
 return message.reply(`**Você não tem permissão para utilizar esse comando!, Permissões exigidas: \`Gerenciar Canais\`.**`)
}
	const canal = await db.ref(`Setsug/Servidores/${message.guild.id}`).once("value")

	
	if (!canal.val()) {
db.ref(`Setsug/Servidores/${message.guild.id}`)
.set({
channelID: message.channel.id,
server_name: message.guild.name,
server_icon: message.guild.iconURL()
})
		const embed_1 = new	Discord.MessageEmbed()
		.addField(`<:emoji_1:869563700774862849> | __**Canal de sugestões setado com sucesso!**.__`,`Mandarei todas as sugestões de membros no canal __**\`${message.channel.name}\`**__.`)
		.setColor('ORANGE')
return message.reply({ embeds: [embed_1]})
} 
	if (canal.val()) {	
		db.ref(`Setsug/Servidores/${message.guild.id}`)
.update({
channelID: message.channel.id
})
		const embed_2 = new	Discord.MessageEmbed()
		.addField('<:emoji_1:869563700774862849> | __**Canal de sugestões atualizado com sucesso!**.__',`\nAgora eu mandarei todas as sugestões de membros no canal __**\`${message.channel.name}\`**__.`)
		.setColor('ORANGE')
		return message.reply({ embeds: [embed_2]})
}
}