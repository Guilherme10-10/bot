const Discord = require("discord.js");
const { MessageEmbed, MessageButton, MessageActionRow, MessageCollector } = require('discord.js');

module.exports = {
    name: "kiss",
    aliases: ["abraço"], 

    run: async(client, message, args) => {
			
		var list = [
 
'https://imgur.com/f8qiCq2.gif', 

'https://imgur.com/xgGBRJc.gif', 

'https://imgur.com/JbdWsLa.gif', 

'https://imgur.com/txNxEz3.gif', 

'https://imgur.com/EpQe6Oj.gif', 

'https://imgur.com/3aX4Qq2.gif', 

'https://imgur.com/6i5zWCx.gif',

'https://imgur.com/uPtDEh6.gif', 

'https://imgur.com/TDVZwUB.gif', 

'https://imgur.com/KSiA3Ws.gif', 

'https://imgur.com/EOMXd5B.gif', 

'https://imgur.com/IWdP2P9.gif', 

'https://imgur.com/gLyYxIK.gif', 

'https://imgur.com/k2X9yOM.gif', 

'https://imgur.com/siVySzs.gif',

'https://imgur.com/glTzPMZ.gif',
  
'https://imgur.com/ma3wNn3.gif',

'https://imgur.com/iz1awkG.gif',

'https://imgur.com/1W7pUeG.gif',

'https://imgur.com/nvAZ85C.gif',

'https://imgur.com/vKzxvjH.gif',

'https://imgur.com/k63RXkx.gif',

'https://imgur.com/92GZK3z.gif',

'https://imgur.com/D4Mf14Y.gif',

'https://imgur.com/YhA5obr.gif',

'https://imgur.com/3gqjT1K.gif',

'https://imgur.com/F5MSJsL.gif',

'https://imgur.com/F3CW53z.gif',

'https://imgur.com/BJsYnSf.gif',

'https://imgur.com/OaCvF85.gif'

	
];

const gif_kiss = list[Math.floor(Math.random() * list.length)];


  let pessoa = message.mentions.users.first() || client.users.cache.get(args[0]);
  
  if (!pessoa) return message.reply(`**❌ | Por favor, mencione alguém.**`);

    if (pessoa.id == message.author.id) return message.reply(`**❌ | Você  precisa mencionar alguém diferente de você.**`);

  const row = new MessageActionRow()
        .addComponents(
            new MessageButton()
                .setCustomId("kiss")
                .setStyle("SECONDARY")
                .setLabel("Retribuir")
                .setEmoji(`<:seta_orange:892694193900748830>`)
                .setDisabled(false),
                              /*  new MessageButton()
                .setCustomId("002")
                .setStyle("SECONDARY")
                .setLabel("cancelar")
                .setEmoji(`<:x_orange:892866734917312533>`)
                .setDisabled(false)*/
                )

  let embed_1 = new Discord.MessageEmbed()
 
 .setDescription(`<:umaru_13:864078237042999306> ${message.author} beijou ${pessoa}`)
  .setImage(gif_kiss)
  .setTimestamp()
  .setColor("ORANGE")
  //.setThumbnail(message.author.displayAvatarURL({format:"png"}))
  .setFooter(`•`, message.author.displayAvatarURL({format:"png"}));

  const me = await message.reply({content: `${message.author}`, embeds: [embed_1], components: [row], fetchReply: true})

const filter1 = (interaction) => {
            if(interaction.user.id == pessoa) return true; 
            else {
                interaction.reply({ content: `** apenas __${pessoa.tag}__  tem permissão de reagir ao botão.**`, ephemeral: true })
            }
        }


const collector = message.channel.createMessageComponentCollector({componentType: 'BUTTON', time: 10 * 6000, filter: filter1, max: 1 })




  collector.on('collect', async (m) => {
            
            if (!pessoa)
            return;
            if (m.customId === 'kiss') {
            me.edit({
                        embeds: [

                        new Discord.MessageEmbed()
                        
                        .setDescription(`<:umaru_13:864078237042999306>${pessoa} retribuiu o beijo de ${message.author}`)
                        .setColor("ORANGE")
                        .setImage(gif_kiss)
                        //.setThumbnail(message.author.displayAvatarURL({format:"png"}))
                        .setFooter(`•`, message.author.displayAvatarURL({format:"png"}))
                                                ]
})
};
 if (m.customId === '002') {
     setTimeout(() => me.delete(), 100)

};
});
        }
		}