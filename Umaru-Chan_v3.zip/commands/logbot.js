const Discord = require("discord.js")
//const cor = require("chalk")
exports.run = async (client, message, args) => {
    //var cmd = message.channel.send
    let servers = client.guilds.cache.map(g => g.name + " - " + g.members.cache.size+"\n")
   // cmd(embed)
const embed = new Discord.MessageEmbed()	
  .setTitle('INFORMACÃO DO BOT')
	.setDescription(`
================================

> **Nome do bot:** \`${client.user.tag}\`

> **Id:** \`${client.user.id}\`

> **Membros:** \`${client.users.cache.size}\`

> **Número de Servidores:** \`( ${client.guilds.cache.size} )\`

> **Servidores:**\n\`${servers}\`


================================

`)
	.setThumbnail(client.user.displayAvatarURL( { dynamic: true } ))
	.setColor("ORANGE")
	. setFooter (`USER PRIVATE: ${message.author.tag} | CMD LOG:`)
	.setTimestamp()
	
	client.users.fetch('435573570240774165', false).then((user) => {
 user.send({ embeds: [embed]});
});
	const ok = new Discord.MessageEmbed()
	.setDescription(`**Ok, Vou enviar o relatório.**\n\n> **Status:** \`Ok\``)
	. setFooter("Código: 0505")
	.setTimestamp()
	message.reply({ embeds: [ok]})
}

