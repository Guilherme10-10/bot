const disbut = require('discord-buttons')
const Discord = require("discord.js");
//const uhelp require('../uhelp.js')
module.exports = {
    name: "help com reação bot umaru-cahan",
    description: "clique na reação, e a msg será editada :)",
    author: "Guilherme",

run: async(client, message, args) => { //embed do painel inicial
let button = new disbut.MessageButton()
  .setStyle('url')
  .setLabel('💻 Servidor de Suporte') 
  .setURL('https://discord.gg/uFGtVsNQY2')
let row = new disbut.MessageActionRow()
  .addComponents(button)
	
    let embed = new Discord.MessageEmbed()
    .setTitle(`<:Ponto:864133309180936223> Painel de Ajuda.`)
    //.setThumbnail(message.guild.iconURL({ dynamic: true, size: 2048 }))
.setDescription(`\n\n>  **REAÇÕES:**\n\n<:seta_orange:892694193900748830> | **VOLTAR**\n\n> <:util_orange:892706348754669578> | **UTILIDADES (13)**.\n\n> <:info_orange:892706244756906014>  | **MODERAÇÃO (4)**.\n\n> <:diverso_orange:892697600795484160> | **DIVERSÃO (8)**.\n\n\> <:imagem_orange:893269589406941245> | **INTERAÇÃO (10)**.\n\n\`[Nya]\`<a:Gata:864133819472019477>
⠀\n\n<:umaru_14:864078268152152074> | __**[SERVIDOR DE SUPORTE](https://discord.gg/uFGtVsNQY2)**__\n\n`)
			.setImage('https://imgur.com/SXDBXkX.png')
    .setFooter(`${message.author.tag}`)
    .setColor("ORANGE")    
    message.lineReply/*channel.send*/(embed).then(msg => {
  msg.channel.send(`**Meu servidor de suporte:**`, row )   
			msg.react("<:seta_orange:892694193900748830> ")
      msg.react("<:util_orange:892706348754669578>")
      msg.react("<:info_orange:892706244756906014>")
      msg.react("<:diverso_orange:892697600795484160>")
      msg.react("<:mais_orange:892705998039552020>")
			msg.react("<:imagem_orange:893269589406941245>")

      let filtro0 = (r, u) => r.emoji.id === '892694193900748830' && u.id === message.author.id
      let filtro1 = (r, u) => r.emoji.id === '892706348754669578' && u.id === message.author.id
      let filtro2 = (r, u) => r.emoji.id === '892706244756906014' && u.id === message.author.id;
      let filtro3 = (r, u) => r.emoji.id === '892697600795484160' && u.id === message.author.id;
      let filtro4 = (r, u) => r.emoji.id === '892705998039552020' && u.id === message.author.id;
      let filtro5 = (r, u) => r.emoji.id === "893269589406941245" && u.id === message.author.id;

      let coletor0 = msg.createReactionCollector(filtro0);
      let coletor = msg.createReactionCollector(filtro1);
      let coletor2 = msg.createReactionCollector(filtro2);
      let coletor3 = msg.createReactionCollector(filtro3);
      let coletor4 = msg.createReactionCollector(filtro4);
     let coletor5 = msg.createReactionCollector(filtro5)

      coletor0.on("collect", c => { //embed do painel inicial (editada)

        let umaru = new Discord.MessageEmbed()
      .setTitle(`<:Ponto:864133309180936223> Painel de Ajuda.`)
      //.setThumbnail(message.guild.iconURL({ dynamic: true, size: 2048 }))
      .setDescription(`\n\n>  **REAÇÕES:**\n\n> <:seta_orange:892694193900748830> | **VOLTAR**\n\n> <:util_orange:892706348754669578> | **UTILIDADES (13)**.\n\n> <:info_orange:892706244756906014>  | **MODERAÇÃO (4)**.\n\n> <:diverso_orange:892697600795484160> | **DIVERSÃO (8)**.\n\n\> <:imagem_orange:893269589406941245> | **INTERAÇÃO (10)**.\n\n\`[Nya]\`<a:Gata:864133819472019477>\n\n<:umaru_14:864078268152152074> | __**[SERVIDOR DE SUPORTE](https://discord.gg/uFGtVsNQY2)**__`)
					.setImage('https://imgur.com/SXDBXkX.png')
      .setFooter(`${message.author.tag}`)
      .setColor("ORANGE")   
        
     
        msg.edit(`${message.author}`, umaru)
      })


      coletor.on("collect", c => { //embed do painel de utilidade (editada)

        let umaruu = new Discord.MessageEmbed()
        .setTitle(`<:umaru_12:864078207736348672> Utilidade`)
        .setThumbnail('https://imgur.com/VeGWAFE.png')
        .setFooter(`${message.author.tag}`)
        .setDescription("**Comandos de Utilidades:**\n\n**Comando: Ver seu avatar ou avatar de alguém.**\n\`u!avatar <usuario>\`\n\n**Comando: Ver ícone do servidor.**\n\`u!servericon\`\n\n**Comando: Enviar uma sugestão no canal de sugestões.**\n\`u!sugestao <sua sugestão>\`\n\n**Comando: Ver informações de usuários.**\n\`u!userinfo <id/menção>\`\n\n**Comando: Ver informações de anime**.\n\`u!anime <anime>\`\n\n**Comando: mostrar capa do anime específico.**\n\`u!animecap <anime>\`\n\n**Comando: Criar um convite do bot.**\n\`u!invite\`\n\n**Comando: criar uma embed.**\n\`u!embeds\`\n\n**Comando: Ver latência do bot.**\n\`u!ping\`\n\n**Comando: Fazer o bot falar algo.**\n\`u!repete <text>\`\n\n**Comando: Tradutor, o bot traduz algo para você.**\n\`u!trad <Text>\`\n\n**Comando: Ver data e horário do dia atual.**\n\`u!calen\`\n\n**Comando: calculadora.**\n\`u!call\`\n\n")
        .setColor("ORANGE")
				
        

        msg.edit(`${message.author}`, umaruu)
      })

      coletor2.on("collect", c => { //embed do painel de moderação (editada)

        let umaruu = new Discord.MessageEmbed()
        .setTitle(`<:umaru_16:864078323520110612> Moderação`)
        .setThumbnail('https://imgur.com/J89fsx7.png')
        .setFooter(`${message.author.tag}`)
        .setDescription(`**Comandos de Moderação:**\n\n**Comando: Bloquear canal de texto.**\n\`u!lock\`\n\n**Comando: Desbloquear canal de texto.**\n\`u!unlock\`\n\n**Comando: Banir membro.**\n\`u!ban <id ou menção do usuário>\`\n\n**Comando: Apagar mensagens.**\n\`u!clear <quantidae>\`\n\n`)
        .setColor("ORANGE")
        

        msg.edit(`${message.author}`, umaruu)
      })

      coletor3.on("collect", c => { //embed do painel de diversão (editada)

        let umaru = new Discord.MessageEmbed()
        .setTitle(`<:umaru_14:864078268152152074> Diversão`)
       .setThumbnail('https://imgur.com/9VDhbey.png')
        .setFooter(`${message.author.tag}`)
        .setDescription(`**Comandos de Diversão:**\n\n**Comando: Frase.**\n\`u!frase <nome de um personagem>\` **OBS: por enquanto so tem dois personagens disponível para esse comando.**\n\n**Comando: Coinflip / Cara ou Coroa.**\n\`u!coinflip <cara/coroa>\`\n\n**Comando: Codificar um texto para códigos binário.**\n\`u!decode <Texto>\`\n\n**Comando: Descodificar códigos binários contendo um texto.**\n\`u!uncode <códigos>\`\n\n**Comando: Criar um clone de alguém.**\n\`u!clone <@membro>\`\n\n**Comando: Frases de Naruto Uzumaki.**\n\`u!naruto\`\n\n**Comando: Fazer o bot contar uma piada.**\n\`u!piada\`\n\n**Comando: reverter palavra.**\n\`u!reverse\`\n\n`)
        .setColor("ORANGE")

        msg.edit(`${message.author}`, umaru)
      })

      coletor4.on("collect", c => { //embed de outros cmds (editada)

        let umaruuu = new Discord.MessageEmbed()
        .setTitle(`<:umaru_10:864078154715758632> Informações`)
        .setThumbnail(client.user.displayAvatarURL())
        .setFooter(`${message.author.tag}`)
        .setDescription(`\n\n<:calendrio_orange:892691199801040916> **| Criado em: 25 de junho, 2021 às 17:50 da tarde**`)
        .setColor("ORANGE")

        msg.edit(`${message.author}`, umaruuu)
      })
	coletor5.on("collect", c => { //embed de outros cmds (editada)

        let umarupc = new Discord.MessageEmbed()
        .setTitle(`<:umaru_10:864078154715758632> Parceiros do bot`)
        .setThumbnail(client.user.displayAvatarURL())
        .setFooter(`${message.author.tag}`)
      .setTitle('🖼️ | INTERAÇÕES')
					//.addField('\n\n🤖 | BOTs PARCEIROS:', 'Nenhum por enquanto.')
.setDescription("**Comandos de interação:**\n\n**Comando: Beijar alguém com interação gif.**\n\`u!kiss <@Usuario>\`\n\n**Comando: abraçar alguém com interação gif.**\n\`u!hug <@Usuario>\`\n\n**Comando: bater em alguém com interação gif.**\n\`u!slap <@Usuario>\`\n\n**Comando: Fazer carinho em alguém com interação gif.**\n\`u!pat <@Usuario>\`\n\n**Comando: procurado.**\n\`u!wanted <usuario>\`\n\n**Comando: delatar alguém com interação IMG.**\n\`u!delete <usuário>\`\n\n**Comando: LGBT+, com interação IMG.**\n\`u!gay <usuário>\`\n\n**Comando: De um BatTapa em alguém com interação IMG.**\n\`u!batslap\`\n\n**Comando: Wallpaper, gera um wallpaper para Desktop (PC).**\n\`u! wallpaperpc\`\n\n**Comando: Wallpaper, gera um wallpaper para Celular (mobile).**\n\`u!wallpapermb\`")
        .setColor("ORANGE")

        msg.edit(`${message.author}`, umarupc)
      })
    })
  }
}