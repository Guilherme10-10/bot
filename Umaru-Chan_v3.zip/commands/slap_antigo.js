const Discord = require('discord.js');
const emotes = require('discord-emotes')
exports.run = async (client, message, args, db) => {



let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.lineReply('**Lembre-se de mencionar um usuário válido para dar um Tapa!**');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
emotes.slap().then(gif => {


let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
       // .setTitle('⠀⠀⠀⠀⠀⠀⠀⠀ \n💢uff Puff \n ⠀⠀⠀⠀⠀⠀⠀⠀')
        .setColor('ORANGE')
        .setDescription(`<:umaru_9:864078095559426048> ${message.author} **bateu em** ${user}`)
        .setImage(gif)
        .setTimestamp()
       // .setThumbnail(avatar)
        .setFooter('Use 🔁 para retribuir.')
        //.setAuthor(message.author.tag, avatar);
        //.setAuthor(displayAvatarURL)
  message.lineReply(message.author, embed).then(msg =>{
		msg.react('🔁')
	})
})
	//message
}