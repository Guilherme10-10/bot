const Discord = require('discord.js');
const emotes = require('discord-emotes')

exports.run = async (client, message, args) => {



let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.lineReply('**Lembre-se de mencionar um usuário válido para dar um abraço!**.');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
emotes.hug().then(gif => {

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
       //.setTitle('<:umaru_7:864077672471461888>')
        .setColor('ORANGE')
        .setDescription(`<a:emoji_17:864082263326588959>${message.author} **abraçou** ${user}`)
        .setImage(gif)
        .setTimestamp()
       // .setThumbnail(avatar)
        .setFooter('Use 🔁 para retribuir.')
       // .setAuthor(message.author.tag, avatar);
  message.lineReply(message.author ,embed).then(msg => {
		msg.react('🔁')
	})
})
}