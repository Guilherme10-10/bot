const diciojs = require('dicionario.js')
const Discord = require ('discord.js')

exports.run = async (client, message, args) => {
const piada = diciojs.piada()

	const embed = new Discord.MessageEmbed()
	.setTitle('😂 | Qual e a piada da vez?')
	.setColor('ORANGE')
	.addField('**<:emoji_69:892908053014392872> | PERGUNTA:**', `${piada.properties.pergunta}`)
		.addField('**<:message_orange:892691299453513759> | RESPOSTA:** ',`${piada.properties.resposta}`)
		
	message.reply({ embeds: [embed]}).then(msg => {
			msg.react('👍🏻')
			msg.react('👎🏻')
		})
}
