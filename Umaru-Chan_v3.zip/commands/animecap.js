const { get } = require("request-promise-native");
const { MessageEmbed } = require("discord.js")
const translate = require('@iamtraction/google-translate')

 module.exports.run = async (client, message, args) => {
  
    if(!args.length) {
      return message.reply("**Por favor, escreva o nome do anime apos o comando.**")
    }
    //DEFINE OPTIONS

let option = {
      url: `https://kitsu.io/api/edge/anime?filter[text]=${args.join(" ")}`,
      method: `GET`,
      headers: {
        'Content-Type': "application/vnd.api+json",
        'Accept': "application/vnd.api+json"

      },
      json: true
	}
	 //body.data[0].attributes
message.reply("**Buscando as informações. . .**").then(msg => {
   msg.delete({timeout: 1000})  
 get(option).then(body => {

	

let img = body.data[0].attributes.posterImage.original;

let fach = body.data[0].attributes.ageRatingGuide

	 

	const embed = new MessageEmbed()
	 .setColor("ORANGE")
   .setImage(img)
.setAuthor(' | Capa do anime:', message.author.displayAvatarURL())
.setTitle(`${body.data[0] .attributes.titles.en_jp}`)
				.setFooter('Use o comando: u!anime, para saber mais.')
				
					.setURL(`https://kitsu.io/${body.data[0].id}`)
			

message.reply({ content: `${message.author}`, embeds: [embed]})
	 
	 })
			})			
}