const Discord = require("discord.js")

exports.run = async (client, message, args, db) => {
	const canal = await db.ref(`Setsug/Servidores/${message.guild.id}`).once("value")
	
if (!canal.val()) {

		const embed_1 = new	Discord.MessageEmbed()
		.setDescription (`**Este Servidor não tem um canal de sugestões definido, use o comando \`u!setchsug\` para definir o canal de sugestões.**`)
	.setColor('ORANGE')
return message.reply({ embeds: [embed_1]})
} 
	message.delete();
	
	var sugestao = args.join(" ")
var channel = canal.val().channelID
	if (!args[0]) {
		return		message.channel.send(`${message.author} ** Digite sua sugestão, apos o comando.**`)
	};
	if (sugestao.length > 1000) {
		return
message.channel.send(`${message.author} ** Escreva uma sugestão de no máximo __1000 Caracteres__.**`)
	};
	if (sugestao.length < 5) {
		return		message.channel.send(`${message.author} **Digite uma sugestão com mais de __5 caracteres.__**`)
	};

	const embedsgo = new Discord.MessageEmbed()
		.setTitle("<:emoji_39:861972961983987812> INFORMAÇÕES DA SUGESTÃO")
		//.setDescription(`> **🙋🏻‍♂️ | MEMBRO:**\n${message.author}\n> **💡 | SUGESTÃO:**\n${sugestao}`)
	  .setColor("ORANGE")
    .addField('> **🙋🏻‍♂️ | MEMBRO:**\n', `${message.author}`)
	  .addField('> **💡 | SUGESTÃO:**\n', `• **${sugestao}**`)
.setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
	.setFooter(`${message.guild.name}`, message.guild.iconURL({ dynamic: true}))
	.setTimestamp()

let canal_send = client.channels.cache.get(channel);

let send_c = client.channels.cache.get(message.channel.id);
	
canal_send.send({ embeds: [embedsgo]}).then(msg => {
	const emojis = ["👍🏻","👎🏻"]

  for (const i in emojis) {
  msg.react(emojis[i])
   }
 });

	send_c.send(`${message.author} **Obrigada pela sua sugestão. O servidor (\`${message.guild.name}\`) agradeçe.**`).then(msg => {		
setTimeout(() => msg.delete(), 10000)
msg.react('<:emoji_1:869563700774862849>')
	
	})

}
																																					


