const Discord = require("discord.js")

exports.run = async (client, message, args) => {



	//const enviar = message.lineReply
	
	const argumento = args.join(" ")

	const m1 = new Discord.MessageEmbed()
.setColor("ORANGE")
	.setDescription(`**Por favor, escreva um nome de um personagem apos o comando.**\n> **Examplos de autores**:\n• Naruto Uzumaki\n• Kakashi Hatake`)
	
	if (!argumento[0]){
		return message.reply({ embeds: [m1]})
	}
	//Frases do naruto
	var naruto_f = [

		'**"Não é o rosto que faz de alguém um monstro, são as escolhas que elas fazem para as suas vidas."**',
		
		'**"Trabalho duro é inútil para aqueles que não acreditam em si mesmos."**',
		
		'**"Lar é onde tem alguém sempre pensando em você."**',
	  
		'**"Desista de me fazer desistir!"**',
	  
		'**"Se você não gosta do seu destino, não aceite. Em vez disso, tenha a coragem de mudá-lo do jeito que você quer que seja."**',
	  
		'**“O fracasso não é razão para você desistir, desde que continue acreditando.”**',
		
		'**"O que dói não é crescer. O que dói é ver uma pessoa que tanto amou mudar."**'
	];
	
	var naruto_frase = naruto_f[Math.floor(Math.random() * naruto_f.length)];
	
	var naruto_img = [

	//	'',
	//	'',
		'https://imgur.com/i3N9SUb.png',
	  //'https://imgur.com/GqYBtvS.png',
	  'https://imgur.com/4ukPiHO.png',
	  'https://imgur.com/IPdi73x.png',
		'https://imgur.com/cMsNpFl.png'
		
	];
	
	var naruto_imagem = naruto_img[Math.floor(Math.random() * naruto_img.length)];
	
	const naruto_embed = new Discord.MessageEmbed()
	.setTitle(`📺 Anime: Naruto`)
		.setURL("https://www.crunchyroll.com/pt-br/naruto")
	.setColor("ORANGE")
	.setDescription(`> **💬 | FRASE:**\n __${naruto_frase}__\n\n• 🧸 | **Personagem:** Naruto Uzumaki\n`)
	.setImage(naruto_imagem)
	//.setTimestamp()
//IFs

	if (argumento === 'naruto'){
return message.reply({ embeds: [naruto_embed]})
	}

	if (argumento === 'Naruto'){
return message.reply({ embeds: [naruto_embed]})
} 

	if (argumento === 'Naruto Uzumaki'){
return message.reply({ embeds: [naruto_embed]})		
}
	
	if (argumento === "naruto uzumaki"){		return message.reply({ embeds: [naruto_embed]})
 }
//kakashi


	var p1_f = [

  '**"Na sociedade, aqueles que não possuem muitas habilidades, tendem a reclamar mais."**',
	
	'**"Esqueça a vingança. O destino dos que procuram a vingança é sombrio. É trágico e você vai acabar sofrendo e se machucando ainda mais. Mesmo que você consiga sua vingança, a única coisa que vai persistir é o vazio."**',
	
	'**"Só porque você enfrenta adversidades e dificuldades, isso não é nenhuma razão para desistir deste mundo. Uma pessoa, disposta a jogar fora todas as memórias de seus amigos e companheiros, nunca vai encontrar paz de espírito. Se você perseverar e suportar, alguém vai estar lá para apoiá-lo."**',
	
	'**"Saber o que é certo e escolher ignorá-lo é um ato de covardia."**'
	
	
];

	var p1_frase = p1_f[Math.floor(Math.random() * p1_f.length)];

	
var p1_i = [

  'https://imgur.com/XYpRxtU.png',
	
	'https://imgur.com/BlHFGiB.png',
	
	'https://imgur.com/OVfAAjx.png',
	
	'https://imgur.com/Duim7N4.png'
	
];

	var p1_img = p1_i[Math.floor(Math.random() * p1_i.length)];

	const p1_embed = new Discord.MessageEmbed()
	.setTitle(`📺 Anime: Naruto`)
	.setURL('https://www.crunchyroll.com/pt-br/naruto')
	.setDescription(`> **💬 | FRASE:**\n__${p1_frase}__\n\n• **🧸 | Personagem:** Hatake Kakashi`)
.setColor("ORANGE")
	.setImage(p1_img)

if (argumento === 'kakashi'){
return message.reply({ embeds: [p1_embed]})
}

	if (argumento === 'Kakashi'){
return message.reply({ embeds: [p1_embed]})
	}
	if (argumento === 'Hatake Kakashi'){
return message.reply({ embeds: [p1_embed]})
	}
	
if (argumento === "Kakashi Hatake"){
	return message.reply({ embeds: [p1_embed]})
}	
	
if (argumento === 'kakashi hatake'){
return message.reply({ embeds: [p1_embed]})
}
} 