 
const Discord = require("discord.js");

exports.run = async (client, message, args) => {

var perms = message.member.permissions.has("MANAGE_MESSAGES")

if(!perms) {
	return message.reply('**Você não tem permissão para executar esse comando.**')
}
	
 const deleteCount = parseInt(args[0], 10);
 if (!deleteCount || deleteCount < 1 || deleteCount > 99)
 return message.reply({content:
 "**🗑️ | Forneça um número de até __99 __mensagens a serem excluídas.**"
 , ephemeral: true}).then(msg => {
	
setTimeout(() => msg.delete(), 5000);
setTimeout(() => message.delete(), 5000);
 })


	const embed = new Discord.MessageEmbed()
	.setColor("ORANGE")
.setDescription(`**Mensagens limpas em \`${message.channel.name}\` por: ${message.author}**`)
	.setTimestamp()
	
 const fetched = await message.channel.messages.fetch({
 limit: deleteCount + 1
 });
 message.channel.bulkDelete(fetched);
 message.channel.send({ content: `${message.author}`, embeds: [embed]}).catch(error =>
 console.log(`Não foi possível deletar mensagens devido a: ${error}`)

 );
};  