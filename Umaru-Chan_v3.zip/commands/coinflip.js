const Discord = require("discord.js")

module.exports.run = async(client, message, args) => {

var embed_404 = []
	
var obj = [
	'cara',
	'coroa'
]	

var object = obj[Math.floor(Math.random() * obj.length)];

const arg = args.join(" ")
	if (!arg){
		const em_5 = new Discord.MessageEmbed()
		.setColor('ORANGE')
		.setDescription(`> **🤔...Escolha \`cara ou coroa\`**`)
		.setImage('https://imgur.com/MeSlbuQ.gif')
		
		return message.reply({embeds: [em_5], ephemeral: true})
	}
	if (arg != 'cara' && arg != 'coroa'){
const em_2 = new Discord.MessageEmbed()
		.setColor('ORANGE')
		.setDescription(`> **🤔...Opção inválida!. Escolha __cara__ ou __coroa__**`)
		.setImage('https://imgur.com/MeSlbuQ.gif')
		
return message.reply({embeds: [em_2]})
	}

const embed_1 = new Discord.MessageEmbed()
	.setTitle("💫 COINFLIP")
	.setDescription(`**Voce escolheu \`${arg}\` deu \`${object}\`, Voce __Ganhou!__ 🙂.**`)
.setColor("ORANGE")
	if (arg == 'coroa' && object == 'coroa'){
		embed_404 = embed_1
	 //return message.reply({ embeds: [embed_1]})
	}
	
const embed_2 = new Discord.MessageEmbed()
.setTitle("💫 COINFLIP")
	.setDescription(`**Voce escolheu \`${arg}\` deu \`${object}\`, Voce __Perdeu!__ 😔.**`)
.setColor("ORANGE")
if (arg == 'coroa' && object == 'cara'){
embed_404 = embed_2
	//return message.reply({ embeds: [embed_2]})
}
const embed_3 = new Discord.MessageEmbed()
.setTitle("💫 COINFLIP")
	.setDescription(`**Voce escolheu \`${arg}\` deu \`${object}\`, Voce __Ganhou!__ 🙂.**`)
.setColor("ORANGE")
if (arg == 'cara' && object == 'cara'){
	embed_404 = embed_3
//return message.reply({ embeds: [embed_3]})
}
const embed_4 = new Discord.MessageEmbed()
.setTitle("💫 COINFLIP")
	.setDescription(`**Voce escolheu \`${arg}\` deu \`${object}\`, Voce __Perdeu!__ 😔.**`)
.setColor("ORANGE")
if (arg == 'cara' && object == 'coroa') {
	embed_404 = embed_4
//return message.reply({ embeds: [embed_4]})
}
const em_4 = new Discord.MessageEmbed()
	.setDescription('> **Jogando a moeda...**')
	.setColor('ORANGE')
	.setImage('https://imgur.com/Q8qKcCl.gif')
	
	
let coinflip_cmd = await message.reply({ content: `${message.author}`, embeds: [em_4] }).then(msg => {
            setTimeout( () => {
                msg.edit({ content: `${message.author}`, embeds: [embed_404] })
            }, 5000)
        })


}