const Discord =  require("discord.js")

exports.run = async (client, message, args, db) => {

const blacklist = await db.ref(`Lista/Usuarios/${message.author.id}`).once("value")
const ssh = new Discord.MessageEmbed()
	.setColor("#2E2E2E")
	.setDescription(`**Voce esta na minha lista negra, então você não pode ultilizar esse comando.**`)
	if (blacklist.val()) {
	return message.lineReply(ssh)
		}

	const embed = new Discord
	.MessageEmbed()
		.setTitle('• LISTA DE EMBEDS')
		.setColor("ORANGE")
	.addField('Embed padrão:', '\`u!embed <text>\`')
	.addField('Embed Azul:',  '\`u!embedblue\`')
	
message.reply({ embeds: [embed]})
}