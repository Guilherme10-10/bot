const Discord = require("discord.js");

exports.run = async (client, message, args) => {
 

	
  const sayMessage = args.join(' ');
  if (!args[0]) {	
return message.reply('**Escreva algo para implementar na embed.**')
	}
const embed = new Discord.MessageEmbed()
	.setColor('ORANGE')
	.setTitle(sayMessage)
	.setFooter(`Autor: ${message.author.tag}`,message.author.displayAvatarURL({dynamic: true}))
	
	message.channel.send({ embeds: [embed]})
}