const Discord = require('discord.js')

exports.run = async (client, message, args) => {
var argu = args.join(' ')
if (!argu) {
return message.reply('**<:x_orange:892866734917312533> Escreva algo para mim reverter.**')
}

function reverter(str) {
let array = str.split('');
return array.reverse().join('')
}
const embed = new Discord.MessageEmbed()
	.setTitle('🧬 Palavra Reversa')
	.setDescription(reverter(argu))
	.setColor('ORANGE')
//.setFooter(`autor: ${message.author.tag}`)

await message.reply({ embeds: [embed]})
}