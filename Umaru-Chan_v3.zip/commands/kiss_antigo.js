const Discord = require('discord.js');
//require("discord-reply")
const { kiss } = require('discord-emotes')

exports.run = async (client, message, args) => {
kiss().then(gif => {

let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.lineReply('**Lembre-se de mencionar um usuário válido para beijar!**');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
       //.setTitle('⠀⠀⠀⠀⠀⠀⠀⠀ \n __Kiss__ __kiss__ \n ⠀⠀⠀⠀⠀⠀⠀⠀')
        .setColor('ORANGE')
        .setDescription(`<:umaru_13:864078237042999306> ${message.author} **Beijou** ${user}`)
        .setImage(gif)
        .setTimestamp()
       // .setThumbnail(avatar)
       .setFooter('Use 🔁 para retribuir.')
       // .setAuthor(message.author.tag, avatar);
 /*await */message.lineReply(message.author, embed).then(msg =>{
		msg.react('🔁')
	})
})
}