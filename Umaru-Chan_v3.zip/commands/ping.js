const Discord = require("discord.js")

module.exports = {
    name: "ping",
    author: " ",

    run: async(client, message, args) => {

        let cor = "ORANGE";

        let ping = client.ws.ping;

        let embed_1 = new Discord.MessageEmbed()
        .setColor(cor)
        .setDescription(`**🏓 • Carregando ping...**`);
        
        let embed_2 = new Discord.MessageEmbed()
        .setColor(cor)
        .setDescription(`**O meu ping: 💻 \`${ping} ms\`.**`);

        let ping_cmd = await message.reply({ content: `${message.author}`, embeds: [embed_1] }).then(msg => {
            setTimeout( () => {
                msg.edit({ content: `${message.author}`, embeds: [embed_2] })
            }, 2000)
        })
    }
}