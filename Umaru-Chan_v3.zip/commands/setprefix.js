exports.run = async(client, message, args, db) => {

	const px = args.join(' '
	const preifx await db.ref(`prefixos/${message.guild.id}`).once('value')

	db.ref(`prefixos/${message.guild.id}`).once('value').set({
		prefixo: px
	})

message.channel.send('Prefix ok')}