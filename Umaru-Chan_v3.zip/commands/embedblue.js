 const { MessageEmbed } = require('discord.js')

module.exports.run = async (client, message, args) => {

	argis = args.join(" ")
	if (!argis) { 
		return message.reply('**Escreva algo para implementar na embed.**') 
							}

	const embed = new MessageEmbed()
	.setColor("BLUE")
  .setDescription(argis)
message.reply({ embeds: [embed]})
	}