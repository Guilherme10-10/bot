 const Discord = require('discord.js');
const moment = require('moment');
moment.locale('pt-br');

exports.run = async (client, message) =>{
const sec = new Date()
        const embed = new Discord.MessageEmbed()
            .setTitle('CALENDÁRIO')
            .setColor('ORANGE')
            .addField('<:calendrio_orange:892691199801040916> Data de Hoje:',` ${moment().format('LL')}`)
            .addField('Dia da Semana:', `${moment().format('dddd')}`)
            .addField('<:relgio_orange:892866703309029386> Hora:', `${sec.getHours()}:${sec.getMinutes()}`)
            //.addField('Data de 10 dias atrás:', `${moment().subtract(10, 'days').calendar()}, ou seja, ${moment().subtract(10, 'days').format('LL')}`)
            //.addField('Daqui a 10 dias:', `${moment().add(10, 'days').calendar()}, ou seja, ${moment().add(10, 'days').format('LL')}`)
            //.setFooter('Zedone | Todos os direitos reservados.', bot.user.displayAvatarURL())
            .setTimestamp()
            .setThumbnail('https://imgur.com/8Pc1TfQ.png');
        message.reply({ embeds: [embed]}); 
}