const Discord = require('discord.js');
exports.run = async (client, message, args) => {
	
 if(!message.member.permissions.has('MANAGE_CHANNELS')) {
 return message.reply(`**Você não tem permissão para utilizar esse comando!, Permissões exigidas: \`Gerenciar Canais\`.**`)
 }
 
 const embedlock = new Discord.MessageEmbed()
 .setTitle('🔒 BLOQUEADO')
 .setDescription(`> **CANAL BLOQUEADO:**\n${message.channel}\n> **AUTOR:**\n${message.author}\n __**everyone**__ **Não tera permissão para mandar mensagens nesse canal de agora em diante.**`)
 .setColor('RED')
 .setTimestamp()
	 .setFooter('Use u!unlock para desbloquear.')

	let channel = message.channel;
    //let roles = message.guild.roles;

    // Finding the locked role.
    let lockRole = guild.roles.find("name", "@everyone");
	role.permissions.remove('SEND_MESSAGES')
/*
    // Enables messages
    channel.overwritePermissions(
        lockRole,
        { "SEND_MESSAGES": false },
    ).catch(console.log);
*/
 message.reply({ embeds: [embedlock]})
 message.react("🔒")
} 