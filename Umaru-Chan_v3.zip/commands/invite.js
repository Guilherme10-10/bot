const { MessageEmbed, MessageButton, MessageActionRow, MessageCollector } = require('discord.js');
require("discord-reply")
exports.run = (client, message, args, db) => {

   
    const embed = new MessageEmbed()
    .setColor('ORANGE')
   .setTitle('> **Me adicione. <:umaru_14:864078268152152074>**')
    .setDescription(`**Para me adicionar ao seu servidor clique no botão abaixo:**`)
    .setFooter('15 Segundos para expiração do CONVITE', client.user.displayAvatarURL({ dynamic: true }))
	
	const button = new MessageActionRow()
        .addComponents(
					new MessageButton()
					
					.setStyle('LINK')
			.setLabel('✉️ CONVITE') 
					//.setCustomId("bt")
			.setURL('https://discord.com/oauth2/authorize?client_id=858086771212288031&permissions=8&scope=bot%20applications.commands')
			.setDisabled('false')
					)
	const but = new MessageActionRow()
        .addComponents(
					new MessageButton()
					
					.setStyle('LINK')
			.setLabel('✉️ CONVITE') 
					//.setCustomId("bt")
			.setURL('https://bit.ly/BotUmaruChan')
			.setDisabled('true')
					)
  
   const embed_2 = new MessageEmbed()
	.setColor('ORANGE')
	.setDescription('**ESPERO QUE TENHA CONSEGUIDO ME ADICIONAR NO SEU SERVIDOR. 🧡**')
	

const me = message.reply({ embeds: [embed], components: [button]}).then(msg => {
            setTimeout( () => {
                msg.edit({ content: `${message.author}`, embeds: [embed_2] , components: [but]})
            }, 15000)
})


	
}