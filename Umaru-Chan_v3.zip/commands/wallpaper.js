const akaneko = require('akaneko')
const { MessageEmbed, MessageButton, MessageActionRow, MessageCollector } = require('discord.js');

module.exports.run = async(client, message) => {

let img_m = await akaneko.mobileWallpapers()

let img_pc = await akaneko.wallpapers()

	var url_img = img_pc

const row = new MessageActionRow()
        .addComponents(
            new MessageButton()
                .setCustomId("pc")
                .setStyle("SECONDARY")
                .setLabel("Pc")
                .setEmoji(`💻`)
                .setDisabled('false'),
new MessageButton()
                .setCustomId("mb")
                .setStyle("SECONDARY")
                .setLabel("Mobile")
                .setEmoji(`📱`)
.setDisabled('false')
		)			

	const row_2 = new MessageActionRow()
        .addComponents(
            new MessageButton()
                .setCustomId("pc_2")
                .setStyle("SECONDARY")
                .setLabel("Pc")
                .setEmoji(`💻`)
                .setDisabled('true'),
new MessageButton()
                .setCustomId("mb_2")
                .setStyle("SECONDARY")
                .setLabel("Mobile")
                .setEmoji(`📱`)
.setDisabled('true')
					
					)

	const bt_pc = new MessageActionRow()
        .addComponents(
					new MessageButton()
					.setStyle('LINK')
			.setLabel('⬇️ BAIXAR') 
			.setURL(img_pc)
			.setDisabled('false')
					)
	const bt_mb = new MessageActionRow()
        .addComponents(
					new MessageButton()
					.setStyle('LINK')
			.setLabel('⬇️ BAIXAR') 
			.setURL(img_m)
			.setDisabled('false')
					)
const embed_pc = new MessageEmbed()
.setAuthor(`${message.author.tag}`, message.author.displayAvatarURL())
.setTitle("🖼️ | Wallpaper para PC(💻)")
.setDescription(`Papéis de parede para Desktop, **[Alta resolução.](${img_pc})**`)
.setColor("ORANGE")
.setImage(img_pc)
.setTimestamp()
.setFooter(`•`, message.author.displayAvatarURL())

	const embed_mb = new MessageEmbed()
.setAuthor(`${message.author.tag}`, message.author.displayAvatarURL())
.setTitle("🖼️ | Wallpaper para Mobile(📱)")
.setDescription(`Papéis de parede para mobile\n **[Alta resolução.](${img_m})**`)
.setColor("ORANGE")
.setImage(img_m)
.setTimestamp()
.setFooter(`•`, message.author.displayAvatarURL())

const embed = new MessageEmbed()
	
.setAuthor(client.user.username, client.user.displayAvatarURL({ dynamic: true }))
	.setDescription(`**${message.author.username} Escolha a plataforma do seu wallpaper:**`)
	.setColor('ORANGE')
	
	
	
	const me = await message.reply({content: `${message.author}`,embeds: [embed],  components: [row], fetchReply: true})

const filter1 = (interaction) => {
   if (me.customId === 'pc') {
		 bt = 'true'
	 }      
	if(interaction.user.id == pessoa) return true; 
}

	const collector = message.channel.createMessageComponentCollector({componentType: 'BUTTON', time: 10 * 6000, max: 1})

	collector.on('collect', async (m) => {
            
            //if (!pessoa)
            //return;
            if (m.customId === 'pc') {
          url_img = img_pc
		//row_2.components[3].setURL(img_pc)					
								me.edit({                        embeds: [embed_pc]
						, components: [bt_pc]}) } else {
						//row_2.components[3].setURL(img_m)
		url_img	= img_m				
me.edit({
								embeds: [embed_mb], components: [bt_mb]
							})
						}
					
										})
	
		}