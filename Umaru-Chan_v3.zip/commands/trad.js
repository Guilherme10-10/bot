const Discord = require("discord.js")
const translate = require('@iamtraction/google-translate')

exports.run = async(client, message, args) =>{
	const text = args.join(" ")
	if (!text) {
return message.reply(`**Escreva uma \`(Frase/Palavra/Texto)\` para eu traduzir apos o comando.**`)
//const lang = args[0]
	}
var emo = [
	'🧡',
	'💚',
	'💜',
	'💙'
]

let emoji = emo[Math.floor(Math.random() * emo.length)];

	let option = {
		texto: text,

		arg: "hello"
}
	translate(text, { to: 'pt' }).then(res => {
		const embed = new Discord.MessageEmbed()
		.setTitle(`${emoji} | TRADUTOR`)
		.addField('🇺🇲 | Palavra:',`${text}`)
		.addField('🇧🇷 | Tradução:',`${res.text}`)
		.setColor("ORANGE")
  message.reply({ embeds: [embed]}); // OUTPUT: You are amazing!
}).catch(err => {
  console.error('Erro:', err);
});
	
												
}