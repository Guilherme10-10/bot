const Discord = require("discord.js");
const { MessageEmbed, MessageButton, MessageActionRow, MessageCollector } = require('discord.js');

module.exports = {
    name: "slap",
    aliases: ["abraço"], 

    run: async(client, message, args) => {



  var list = [

'https://imgur.com/RFWNaoF.gif',

'https://imgur.com/oOCq3Bt.gif',

'https://imgur.com/YA7g7h7.gif',

'https://imgur.com/mIg8erJ.gif',

'https://imgur.com/oRsaSyU.gif',

'https://imgur.com/CwbYjBX.gif',

'https://imgur.com/ZlBexLn.gif',

'https://imgur.com/fpabdc9.gif',

'https://imgur.com/6ELKkNO.gif',

'https://imgur.com/td3nSX3.gfi',

'https://imgur.com/CqCz3AN.gif',

'https://imgur.com/gBSf9lk.gif',

'https://imgur.com/F7WGcpa.gif',

'https://imgur.com/SMskPot.gif',

'https://imgur.com/orjYBoH.gfi',

'https://imgur.com/8p95SIi.gif',

'https://imgur.com/qlQCONM.gif',

'https://imgur.com/NaLhZ8m.gif',

'https://imgur.com/zLAI8uT.gif', 

'https://imgur.com/eBsAgfs.gif', 

'https://imgur.com/SMskPot.gif', 

'https://imgur.com/orjYBoH.gif', 

'https://imgur.com/vGWRx6W.gif', 

'https://imgur.com/G3KWX8r.gif', 

'https://imgur.com/Ykdn6yD.gif', 

'https://imgur.com/uUM05Mu.gif', 

'https://imgur.com/w66ZqGR.gif', 

'https://imgur.com/nuDmQu5.gif', 

'https://imgur.com/wYnmA4s.gif', 

'https://imgur.com/GQIGGII.gif', 

'https://imgur.com/jArgSfw.gif', 

'https://imgur.com/uqJEAxg.gif', 

'https://imgur.com/EhJ5aZ0.gif', 

'https://imgur.com/3t2xNmE.gif', 

'https://imgur.com/7l1SN5L.gif', 

'https://imgur.com/jIq6RcZ.gif', 

'https://imgur.com/hvU4fCG.gif', 

'https://imgur.com/eRDDdpf.gif'


  ];

    var list1 = [
   'https://imgur.com/RFWNaoF.gif',

'https://imgur.com/oOCq3Bt.gif',

'https://imgur.com/YA7g7h7.gif',

'https://imgur.com/mIg8erJ.gif',

'https://imgur.com/oRsaSyU.gif',

'https://imgur.com/CwbYjBX.gif',

'https://imgur.com/ZlBexLn.gif',

'https://imgur.com/fpabdc9.gif',

'https://imgur.com/6ELKkNO.gif',

'https://imgur.com/td3nSX3.gfi',

'https://imgur.com/CqCz3AN.gif',

'https://imgur.com/gBSf9lk.gif',

'https://imgur.com/F7WGcpa.gif',

'https://imgur.com/SMskPot.gif',

'https://imgur.com/orjYBoH.gfi',

'https://imgur.com/8p95SIi.gif',

'https://imgur.com/qlQCONM.gif',

'https://imgur.com/NaLhZ8m.gif',

'https://imgur.com/zLAI8uT.gif', 

'https://imgur.com/eBsAgfs.gif', 

'https://imgur.com/SMskPot.gif', 

'https://imgur.com/orjYBoH.gif', 

'https://imgur.com/vGWRx6W.gif', 

'https://imgur.com/G3KWX8r.gif', 

'https://imgur.com/Ykdn6yD.gif', 

'https://imgur.com/uUM05Mu.gif', 

'https://imgur.com/w66ZqGR.gif', 

'https://imgur.com/nuDmQu5.gif', 

'https://imgur.com/wYnmA4s.gif', 

'https://imgur.com/GQIGGII.gif', 

'https://imgur.com/jArgSfw.gif', 

'https://imgur.com/uqJEAxg.gif', 

'https://imgur.com/EhJ5aZ0.gif', 

'https://imgur.com/3t2xNmE.gif', 

'https://imgur.com/7l1SN5L.gif', 

'https://imgur.com/jIq6RcZ.gif', 

'https://imgur.com/hvU4fCG.gif', 

'https://imgur.com/eRDDdpf.gif'



  ];

  var rand = list[Math.floor(Math.random() * list.length)];
    var rand1 = list1[Math.floor(Math.random() * list.length)];
  let pessoa = message.mentions.users.first() || client.users.cache.get(args[0]);
  
  if (!pessoa) return message.reply(`**❌ | Por favor, mencione alguém.**`);

    if (pessoa.id == message.author.id) return message.reply(`**❌ | Você  precisa mencionar alguém diferente de você.**`);

  const row = new MessageActionRow()
        .addComponents(
            new MessageButton()
                .setCustomId("hug")
                .setStyle("SECONDARY")
                .setLabel("retribuir")
                .setEmoji(`<:seta_orange:892694193900748830>`)
                .setDisabled(false),
                              /*  new MessageButton()
                .setCustomId("002")
                .setStyle("SECONDARY")
                .setLabel("cancelar")
                .setEmoji(`<:x_orange:892866734917312533>`)
                .setDisabled(false)*/
                )

  let kazinho = new Discord.MessageEmbed()
 
 .setDescription(`<:umaru_8:864077721008603146>${message.author} bateu em ${pessoa}`)
  .setImage(rand)
  .setTimestamp()
  .setColor("ORANGE")
  //.setThumbnail(message.author.displayAvatarURL({format:"png"}))
  .setFooter(`•`, message.author.displayAvatarURL({format:"png"}));

  const me = await message.reply({content: `${message.author}`, embeds: [kazinho], components: [row], fetchReply: true})

const filter1 = (interaction) => {
            if(interaction.user.id == pessoa) return true; 
            else {
                interaction.reply({ content: `** apenas __${pessoa.tag}__  tem permissão de reagir ao botão.**`, ephemeral: true })
            }
        }


const collector = message.channel.createMessageComponentCollector({componentType: 'BUTTON', time: 10 * 6000, filter: filter1, max: 1 })




  collector.on('collect', async (m) => {
            
            if (!pessoa)
            return;
            if (m.customId === 'hug') {
            me.edit({
                        embeds: [

                        new Discord.MessageEmbed()
                        
                        .setDescription(`<:umaru_8:864077721008603146>${pessoa} retribuiu o tapa de ${message.author}`)
                        .setColor("ORANGE")
                        .setImage(rand1)
                        //.setThumbnail(message.author.displayAvatarURL({format:"png"}))
                        .setFooter(`•`, message.author.displayAvatarURL({format:"png"}))
                                                ]
})
};
 if (m.customId === '002') {
     setTimeout(() => me.delete(), 100)

};
});
        }
		}