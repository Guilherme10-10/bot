const Discord = require("discord.js")

exports.run = async(bot, message, args, db)=> { // Aqui definimos nosso client, 


	
let membro = message.mentions.users.first() || message.author;
	//let member = `<@${membro}>`
 
 let img = membro.displayAvatarURL({ format: 'png', dynamic: true, size: 4096}) // puxa o avatar do membro
 
 const embed = new Discord.MessageEmbed() // cria a embed
 .setTitle(`🖼️ ${membro.tag}`)
 .setDescription(`**Clique [Aqui](${img}) para baixar o avatar.**`)
 .setURL(img)
 .setColor("ORANGE")
 .setImage(img)
 .setFooter(message.guild.name)
 .setTimestamp()
 
 message.reply({embeds: [embed]}) // envia a embed 
}