var list = [

'https://imgur.com/BKOxZb7.gif',

'https://imgur.com/UKYDxVe.gif',

'https://imgur.com/j3JsmPd.gif',

'https://imgur.com/fyymfiZ.gif',

'https://imgur.com/uxBbg6G.gif',

'https://imgur.com/DUsaZ4c.gif',

'https://imgur.com/3m999hb.gif',

'https://imgur.com/eIEKQpx.gif',

'https://imgur.com/i1FAt4t.gif',

'https://imgur.com/nrdYNtL.gif',

'https://imgur.com/BPLqSJC.gif',

'https://imgur.com/ntqYLGl.gif',

'https://imgur.com/82xVqUg.gif'


];

var rand = list[Math.floor(Math.random() * list.length)];