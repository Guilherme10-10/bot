var list = [
  
'https://imgur.com/RFWNaoF.gif',

'https://imgur.com/oOCq3Bt.gif',

'https://imgur.com/YA7g7h7.gif',

'https://imgur.com/mIg8erJ.gif',

'https://imgur.com/oRsaSyU.gif',

'https://imgur.com/CwbYjBX.gif',

'https://imgur.com/ZlBexLn.gif',

'https://imgur.com/fpabdc9.gif',

'https://imgur.com/6ELKkNO.gif',

'https://imgur.com/td3nSX3.gfi',

'https://imgur.com/CqCz3AN.gif',

'https://imgur.com/gBSf9lk.gif',

'https://imgur.com/F7WGcpa.gif',

'https://imgur.com/SMskPot.gif',

'https://imgur.com/orjYBoH.gfi',

'https://imgur.com/8p95SIi.gif',

'https://imgur.com/qlQCONM.gif',

'https://imgur.com/NaLhZ8m.gif',

'https://imgur.com/zLAI8uT.gif', 

'https://imgur.com/eBsAgfs.gif', 

'https://imgur.com/SMskPot.gif', 

'https://imgur.com/orjYBoH.gif', 

'https://imgur.com/vGWRx6W.gif', 

'https://imgur.com/G3KWX8r.gif', 

'https://imgur.com/Ykdn6yD.gif', 

'https://imgur.com/uUM05Mu.gif', 

'https://imgur.com/w66ZqGR.gif', 

'https://imgur.com/nuDmQu5.gif', 

'https://imgur.com/wYnmA4s.gif', 

'https://imgur.com/GQIGGII.gif', 

'https://imgur.com/jArgSfw.gif', 

'https://imgur.com/uqJEAxg.gif', 

'https://imgur.com/EhJ5aZ0.gif', 

'https://imgur.com/3t2xNmE.gif', 

'https://imgur.com/7l1SN5L.gif', 

'https://imgur.com/jIq6RcZ.gif', 

'https://imgur.com/hvU4fCG.gif', 

'https://imgur.com/eRDDdpf.gif'

];
var rand = list[Math.floor(Math.random() * list.length)];