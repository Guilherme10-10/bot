const cor = require("chalk")
module.exports = (client) => {
    var cmd = console.log


      
    let servers = client.guilds.cache.map(g => g.name + " - " + g.members.cache.size+"\n")
    cmd(cor.yellow(`
==========================================

Nome: ${client.user.tag}

Id: ${client.user.id}

Membros: ${client.users.cache.size}

Quantidade de servidores: (${client.guilds.cache.size})

Nomes dos servidores: 
${servers}

==========================================

`))
}

