const color = require("chalk")

module.exports = async(client, guild) =>{
  console.log(color.yellow(`🧡 Fui adicionada no Servidor: ${guild.name} com ${guild.memberCount} Membros.( 😉 )`))
}