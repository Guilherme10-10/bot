module.exports = async(client, guild) =>{
  console.log(guild)
}