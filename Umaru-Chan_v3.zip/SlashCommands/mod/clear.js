const Discord = require('discord.js')

module.exports = {

    name: 'clear',

    description: "[🗑️] Limpe mensagens em chat's.",

    type: 'CHAT_INPUT',

    options: [

        {

            name: 'value',

            description: ' Específique a quantidade de mensagens a serem deletadas (Min: 1 • Max: 99)',

            type: 'NUMBER',

            required: true,

        }

    ],

    run: async (client, interaction, args) => {



        let numero = interaction.options.getNumber('value')



        if (!interaction.member.permissions.has("MANAGE_MESSAGES")) {

            interaction.reply({ content: `Você não tem permissões necessária :(`, ephemeral: true })

        } else



        if (parseInt(numero) > 99 || parseInt(numero) <= 0) {

            return interaction.reply({

                embeds: [

                    new Discord.MessageEmbed()

                    .setDescription(`**Quantidade mínima: \`(1)M\` Máximo \`(99)M\`.**`)

                    .setColor('ORANGE')

                ], ephemeral: true

            })

        } else {



        interaction.channel.bulkDelete(parseInt(numero))



      const embed = new Discord.MessageEmbed()
	.setColor("ORANGE")
.setDescription(`**Mensagens limpas em \`${interaction.channel.name}\` por: ${interaction.member}**`)
	.setTimestamp()
	

            .setColor('ORANGE')



        interaction.reply({ embeds: [embed] }).then(() => {

            setTimeout(() => {

                interaction.deleteReply()

            }, 15000)

        })



    }



    }

					}