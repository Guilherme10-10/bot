const Discord = require("discord.js");
const { MessageEmbed, MessageButton, MessageActionRow, MessageCollector } = require('discord.js');

module.exports =  {
    name: "hug",
    description: "[🤗] abraçar alguém com interação Gif.",
    type: "MENTIONABLE",
    options: [
        {
            name: "user",
            type: "USER",
            description: "Mencione um usuário:",
            required: true
            
        }
    
    ],
    
    run: async (client, interaction, message, args) => {

		var list = [

			'https://imgur.com/RgfGLNk.gif',
    'https://i.imgur.com/r9aU2xv.gif',
    'https://i.imgur.com/wOmoeF8.gif',
    'https://i.imgur.com/nrdYNtL.gif',
    'https://imgur.com/82xVqUg.gif',
		'https://imgur.com/BKOxZb7.gif',

'https://imgur.com/UKYDxVe.gif',

'https://imgur.com/j3JsmPd.gif',

'https://imgur.com/fyymfiZ.gif',

'https://imgur.com/uxBbg6G.gif',

'https://imgur.com/DUsaZ4c.gif',

'https://imgur.com/3m999hb.gif',

'https://imgur.com/eIEKQpx.gif',

'https://imgur.com/i1FAt4t.gif',

'https://imgur.com/nrdYNtL.gif',

'https://imgur.com/BPLqSJC.gif',

'https://imgur.com/ntqYLGl.gif',

'https://imgur.com/82xVqUg.gif'
	
];

const gif_kiss = list[Math.floor(Math.random() * list.length)];
	
const pessoa = interaction.options.getMember('user')
  
  if (!pessoa) return interaction.reply({ content:`**❌ | Por favor, mencione alguém.**`, ephemeral: true });

    if (pessoa.id == interaction.user.id) return interaction.reply({ content: `**❌ | Você  precisa mencionar alguém diferente de você.**`, ephemeral: true });

  

  let embed_1 = new Discord.MessageEmbed()
 
 .setDescription(`<:umaru_13:864078237042999306> ${interaction.user} abraçou ${pessoa}`)
  .setImage(gif_kiss)
  .setTimestamp()
  .setColor("ORANGE")

.setFooter(`•`, interaction.user.displayAvatarURL({format:"png"}));

			

interaction.reply({content: `${pessoa}`, embeds: [embed_1], ephemeral: false})

			
                                      
        }
}
    
