const { MessageEmbed, MessageButton, MessageActionRow, MessageCollector } = require('discord.js')
const akaneko = require('akaneko')

module.exports =  {
    name: "wallpaper",
    description: "[🖼️] Wallpaper para Pc(Desktop) ou Mobile(Celular)",
    type: "CHAT_INPUT",
    options: [
        {
            name: "tipo",
            type: "STRING",
            description: "Escolha a plataforma:",
            required: true,
				    choices: [
   {
      name: 'Pc',
      value: 'Pc',
   },
   {
      name: 'Mobile',
      value: 'Mobile',
   }
]
				}     
    
    ],    
    run: async (client, interaction, args) => {
			const choices = interaction.options.getString('tipo')

let img_m = await akaneko.mobileWallpapers()

let img_pc = await akaneko.wallpapers()

button = ''
caxa = ''
embed = ''
	
		const embed_pc = new MessageEmbed()

.setTitle("🖼️ | Wallpaper para PC(💻)")
.setDescription(`Papel de parede para Desktop, **[Alta resolução.](${img_pc})**`)
.setColor("ORANGE")
.setImage(img_pc)
.setTimestamp()
.setFooter(`•`, interaction.user.displayAvatarURL())

			const embed_mb = new MessageEmbed()

.setTitle("🖼️ | Wallpaper para Mobile(📱)")
.setDescription(`Papel de parede para mobile\n **[Alta resolução.](${img_m})**`)
.setColor("ORANGE")
.setImage(img_m)
.setTimestamp()
.setFooter(`•`, interaction.user.displayAvatarURL())
			
const bt_pc = new MessageActionRow()
        .addComponents(
					new MessageButton()
					.setStyle('LINK')
			.setLabel('⬇️ BAIXAR') 
			.setURL(img_pc)
			.setDisabled('false')
					)
	const bt_mb = new MessageActionRow()
        .addComponents(
					new MessageButton()
					.setStyle('LINK')
			.setLabel('⬇️ BAIXAR') 
			.setURL(img_m)
			.setDisabled('false')
					)			
			if(choices  === 'Pc')	{
				caxa = img_pc
	        embed = embed_pc	
         button = bt_pc
					}
			if(choices === 'Mobile') {
				caxa = img_m
				embed = embed_mb

				button = bt_mb			}
interaction.reply({content: `${interaction.user}`, embeds: [embed], components: [button], ephemeral: false})

		}
}