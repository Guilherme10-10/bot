const { MessageEmbed } = require('discord.js')
module.exports =  {
    name: "embed_info",
    description: "[📄] informações sobre a criação de embed no comando slash.",
    type: "CHAT_INPUT",
    /*options: [
        {
            name: "titulo",
            type: "STRING",
            description: "Escreva o título da embed",
            required: true
            
        }
    
    ],
	*/
    run: async (client, interaction, args) => {
			
			const embed = new MessageEmbed()
				.setTitle(`Como criar uma embed?`)	
				.setDescription(`Nosso sistema de \`SlashCommand\` permite os donos de servidores criarem uma embed de acordo com os seus gostos.\n\n...`)
			.setColor('ORANGE')
			
			interaction.reply({ embeds: [embed]})
		}
}