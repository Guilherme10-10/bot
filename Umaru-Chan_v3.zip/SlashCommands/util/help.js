const Discord = require("discord.js");
const { MessageSelectMenu, MessageActionRow } = require("discord.js")


module.exports =  {
    name: "help",
    description: "[📄] Comando ajuda a mostrar a lista de comandos.",
    type: "CHAT_INPUT",
   
    
    run: async (client, interaction, args) => {


        let embed_1 = new Discord.MessageEmbed()
        .setColor("ORANGE")
.setTitle(`------------------------------------------------------------\n<:Ponto:864133309180936223> Painel de Ajuda.`)
					.setImage('https://imgur.com/Q9Rq10Z.png')
        .setAuthor(client.user.username, client.user.displayAvatarURL({ dynamic: true }))
        .setDescription(`**Olá ${interaction.user.username}, veja meus comandos com o menu abaixo:**\n\n<:umaru_14:864078268152152074> | __**[SERVIDOR DE SUPORTE](https://discord.gg/uFGtVsNQY2)**__`);
	

        let painel = new MessageActionRow().addComponents( new MessageSelectMenu()
        .setCustomId('menu')
        .setPlaceholder('Veja meus comandos.') // Mensagem estampada
        .addOptions([
               {
                    label: 'Painel inicial',
                    description: 'Apenas o painel inicial da mensagem',
                    emoji: '<:seta_orange:892694193900748830>',
                    value: 'painel_inicial',
               },
                {
                    label: 'UTILIDADE',
                    description: 'Meus comandos de utilidade.',
                    emoji: '<:util_orange:892706348754669578>',
                    value: 'utilidade',
                },
                {
                    label: 'MODERAÇÃO',
                    description: 'Meus comandos de moderação.',
                    emoji: '<:info_orange:892706244756906014>',
                    value: 'moderacao',
                },
             {
                    label: 'DIVERSÃO',
                    description: 'Meus comandos de diversão.',
                    emoji: '<:diverso_orange:892697600795484160>',
                    value: 'diversao',
                },
                {
                    label: 'INTERAÇÃO',
                    description: 'Meus comandos de interação',
                    emoji: '<:imagem_orange:893269589406941245>',
                    value: 'outros',
                },
            ])

        );


       interaction.reply({ content: `${interaction.user}`, embeds: [embed_1], components: [painel] }).then(() => {

            const filtro = (i) =>          i.customId == 'manu'/*i.isSelectMenu()*/
																						 				
				   
            const coletor = interaction.channel.createMessageComponentCollector({filtro, time: 300000})
			
            coletor.on('collect', async (collected) => {

              let valor = collected.values[0]
             collected.deferUpdate()

        if (valor === 'painel_inicial') {

             interaction.editReply({ content: `${interaction.user}`, embeds: [embed_1], components: [painel] });
    
        };
        
        if (valor === 'utilidade') {

            let embed_2 = new Discord.MessageEmbed()
           // .setColor("ORANGE")
            .setAuthor(client.user.username, client.user.displayAvatarURL({ dynamic: true }))
            .setTitle(`<:umaru_12:864078207736348672> Utilidade`)
        .setThumbnail('https://imgur.com/VeGWAFE.png')
        .setFooter(`${interaction.user.tag}`)
        .setDescription("**Comandos de Utilidades:**\n\n**Comando: Ver seu avatar ou avatar de alguém.**\n\`u!avatar <usuario>\`\n\n**Comando: Ver ícone do servidor.**\n\`u!servericon\`\n\n**Comando: Ver informações de anime**.\n\`u!anime <anime>\`\n\n**Comando: mostrar capa do anime específico.**\n\`u!animecap <anime>\`\n\n**Comando: Criar um convite do bot.**\n\`u!invite\`\n\n**Comando: criar uma embed.**\n\`u!embeds\`\n\n**Comando: Ver latência do bot.**\n\`u!ping\`\n\n**Comando: Fazer o bot falar algo.**\n\`u!repete <text>\`\n\n**Comando: Tradutor, o bot traduz algo para você.**\n\`u!trad <Text>\`\n\n**Comando: Ver data e horário do dia atual.**\n\`u!calen\`\n\n**Comando: Ver informações do bot.** \n\`u!botinfo\`\n\n")   .setColor("ORANGE")

            interaction.editReply({ content: `${interaction.user}`, embeds: [embed_2], components: [painel] });

        };

        if (valor === 'moderacao') {

            let embed_3 = new Discord.MessageEmbed()
            //.setColor("ORANGE")
            .setAuthor(client.user.username, client.user.displayAvatarURL({ dynamic: true }))
            .setTitle(`<:umaru_16:864078323520110612> Moderação`)
        .setThumbnail('https://imgur.com/J89fsx7.png')
        .setFooter(`${interaction.user.tag}`)
        .setDescription(`**Comandos de Moderação:**\n\n**Comando: Apagar mensagens.**\n\`u!clear <quantidae>\`\n\n`)
        .setColor("ORANGE")

            interaction.editReply({ content: `${interaction.user}`, embeds: [embed_3], components: [painel] });

        };

        if (valor === 'diversao') {

            let embed_4 = new Discord.MessageEmbed()
            //.setColor("ORANGE")
            .setAuthor(client.user.username, client.user.displayAvatarURL({ dynamic: true }))
            .setTitle(`<:umaru_14:864078268152152074> Diversão`)
       .setThumbnail('https://imgur.com/9VDhbey.png')
        .setFooter(`${interaction.user.tag}`)
        .setDescription(`**Comandos de Diversão:**\n\n**Comando: Frase.**\n\`u!frase <nome de um personagem>\` **OBS: por enquanto so tem dois personagens disponível para esse comando.**\n\n**Comando: Coinflip / Cara ou Coroa.**\n\`u!coinflip <cara/coroa>\`\n\n**Comando: Fazer o bot contar uma piada.**\n\`u!piada\`\n\n**Comando: reverter palavra.**\n\`u!reverse\`\n\n**Comando: Akinator, faz akinator advinhar um personagem, objetos e animais.**\n\`u!aki\`\n\n`)
        .setColor("ORANGE")

            interaction.editReply({ content: `${interaction.user}`, embeds: [embed_4], components: [painel] });

        };

        if (valor === 'outros') {

            let embed_5 = new Discord.MessageEmbed()
            //.setColor("ORANGE")
            .setAuthor(client.user.username, client.user.displayAvatarURL({ dynamic: true }))
            .setThumbnail(client.user.displayAvatarURL())
        .setFooter(`${interaction.user.tag}`)
      .setTitle('🖼️ | INTERAÇÕES')
					//.addField('\n\n🤖 | BOTs PARCEIROS:', 'Nenhum por enquanto.')
.setDescription("**Comandos de interação:**\n\n**Comando: Beijar alguém com interação gif.**\n\`u!kiss <@Usuario>\`\n\n**Comando: abraçar alguém com interação gif.**\n\`u!hug <@Usuario>\`\n\n**Comando: bater em alguém com interação gif.**\n\`u!slap <@Usuario>\`\n\n**Comando: Wallpaper, gera um wallpaper.**\n\`u!wallpaper\`")
        .setColor("ORANGE")

            interaction.editReply({ content: `${interaction.user}`, embeds: [embed_5], components: [painel] });

        };
        
        
        })

			 })

			 }
																																			 											     
}