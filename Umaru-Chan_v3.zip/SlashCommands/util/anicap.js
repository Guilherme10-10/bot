const { get } = require("request-promise-native");
const { MessageEmbed } = require("discord.js")
module.exports = {
	name: 'anicap',
	description: '[🎎] Mostra a capa do anime específico.',
	type: 'CHAT_INPUT',
	options: [
		{
			name: 'anime',
			description: 'nome do anime?',
			type: 'STRING',
      required: 'true'
				}
	],

run: async (client, interaction, args) => {
	const an = interaction.options.getString('anime')
	let option = {
      url: `https://kitsu.io/api/edge/anime?filter[text]=${an}`,
      method: `GET`,
      headers: {
        'Content-Type': "application/vnd.api+json",
        'Accept': "application/vnd.api+json"

      },
      json: true
	}
	 //body.data[0].attributes
interaction.reply("**Buscando as informações. . .**").then(msg => {
  // msg.delete({timeout: 1000})  
 get(option).then(body => {

	

let img = body.data[0].attributes.posterImage.original;

let fach = body.data[0].attributes.ageRatingGuide

	 

	const embed = new MessageEmbed()
	 .setColor("ORANGE")
   .setImage(img)
.setAuthor(' | Capa do anime:', interaction.user.displayAvatarURL())
.setTitle(`${body.data[0] .attributes.titles.en_jp}`)
				.setFooter('Use o comando: /anime, para saber mais.')
				
					.setURL(`https://kitsu.io/${body.data[0].id}`)
			

interaction.editReply({ content: `${interaction.user}`, embeds: [embed]})
	 
	 })
			})			
}
 }
