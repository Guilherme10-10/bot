const malScraper = require("mal-scraper");
const translate = require("@iamtraction/google-translate");
const moment = require("moment");
const { MessageButton, MessageEmbed, MessageActionRow } = require("discord.js");

module.exports =  {
    name: "anime",
    description: "[🎎] Mostrar informações de animes",
    type: "CHAT_INPUT",
    options: [
			{
				        
					 name: "nome",
            type: "STRING",
            description: "Escreva o nome do anime.",
            required: true
            
        }
    
    
    
 ],
			

	run: async (client, interaction, args) => {

interaction.reply({content: '**<a:typing:393848431413559296> | Pesquisando aguarde...🔎**' })
		
    const search = interaction.options.getString('nome')
    

    const data = await malScraper.getInfoFromName(search);

    const trad = await translate(data.synopsis, {
     to: "pt-BR".slice(0, 2),
    });

    const date = data.aired.split(" to ").map((x) => x.replace(",", ""));

    const ANIME = new MessageEmbed()
      .setColor("ORANGE")
			.setDescription(
        `**🎎 [${data.title}](${data.url})**\n${
          trad.text.length > 300 ? trad.text.slice(0, 800) + "..." : trad.text
        }`
      )
      .setThumbnail(data.picture)
			
.setTimestamp()
      .addFields(
        {
          name: `🔶 | Episódios:`,
          value: data.episodes.toLocaleString().replace("Unknown", "Em produção."),
          inline: true,
        },
        {
          name: `📺 | Tipo:`,
          value: data.type,
          inline: true,
        },
        {
          name: `🏆 | Rank:`,
          value: data.ranked,
          inline: true,
        },
        {
          name: `❤️ | Popularidade:`,
          value: data.popularity,
          inline: true,
        },
        {
          name: `💠 | Status:`,
          value: data.status
            .replace("Finished Airing", "Finalizado")
            .replace("Currently Airing", "Em produção."),
          inline: true,
        },
        {
          name: `💫 | Categoria's:`,
          value: data.source.replace("Unknown", "Não encontrei :("),
          inline: true,
        },
        {
          name: `🗓️ | Informações sobre Lançamento:`,
          value:
            date[1] == "?" || !date[1]
              ? `**${moment(new Date(date[0])).format("L")}**`
              : `**${moment(new Date(date[0])).format("L")}** - **${moment(
                  new Date(date[1])
                ).format("L")}**`,
          inline: true,
        },
        {
          name: `🕘 | Duração por Episódio:`,
          value: data.duration.replace(". per ep", ""),
          inline: true,
        },
        {
          name: `👌 | Gêneros:`,
          value: data.genres.map((x) => x).join(", "),
          inline: false,
        },
        {
          name: `⭐ | Avaliação:`,
          value: data.score,
          inline: true,
        }
      );
		
		 const bt = new MessageActionRow()
        .addComponents(
					new MessageButton()
					
					.setStyle('LINK')
			.setLabel('🎬 TRAILER') 
					//.setCustomId("bt")
			.setURL('https://bit.ly/BotUmaruChan')
			.setDisabled('true')
					)
			

    if (data.trailer != undefined) {
    /*  
			ANIME.addField(
        `🎬 | Trailer:`,
        `**[Clique Aqui](${data.trailer})**`,
        true
)
				*/
			bt.components[0].setDisabled('false')
					}
		
			
			
			

//await interaction.reply({content: '🔎 | Pesquisando...' })
const result = await ANIME
await	interaction.editReply({content: `${interaction.user}`, embeds:[result], ephemeral: false, components: [bt] });

	}
}	   
