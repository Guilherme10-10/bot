const { MessageEmbed } = require('discord.js')

module.exports =  {
    name: "embed_create",
    description: "[🎛️] Construa sua própria EMBED.",
    type: "CHAT_INPUT",
    options: [
        
						{
					name: "content",
            type: "STRING",
            description: "Escreva o content da mensagem.",
            required: true
				},
			  {
				name: "titulo",
				type: "STRING",
				description: "Escreva o título da embed.",
				required: true
			  },
			  {
				name: "cor",
				type: "STRING",
				description: "Escreva a cor da embed.",
				required: false,


					choices: [
   {
      name: 'azul',
      value: 'azul',
   },
      {
      name: 'amarelo',
      value: 'amarelo',
   },
      {
      name: 'roxo',
      value: 'roxo',
   },
   {
      name: 'rosa',
      value: 'rosa',
   },
   {
      name: 'branco',
      value: 'branco',
   },
   {
      name: 'verde',
      value: 'verde',
   },
   {
      name: 'vermelho',
      value: 'vermelho',
   },
   {
      name: 'preto',
      value: 'preto',
   },
  {
      name: 'laranja',
      value: 'laranja',
   },
   {
      name: 'cinza',
      value: 'cinza',
   },
]
			  },
			  {
				name: "descricao",
				type: "STRING",
				description: "Escreva a descrição da embed.",
				required: false
			  },
			  
			  {
				name: "footer",
				type: "STRING",
				description: "Escreva o radape da embed.",
				required: false
			  },
			  {
				name: "imagem_url",
				type: "STRING",
				description: "Escreva a URL da imagem.",
				required: false
			  },
			  {
				name: "thumbnail_url",
				type: "STRING",
				description: "Escreva a URL da thumbnail da embed.",
				required: false
			  }
    ],    
    run: async (client, interaction, args) => {
    
    
var perms = interaction.member.permissions.has("MANAGE_MESSAGES")

if(!perms) {
	return interaction.reply('**Você não tem permissão para utilizar esse comando :(**')
}
    //const content_embed = interaction.options.getString('tipo')
    
const content_embed = interaction.options.getString('content')

const titulo_embed = interaction.options.getString('titulo')
var cor = ''
const cor_embed = interaction.options.getString('cor')
switch (cor_embed) {
  case 'azul':
    cor = 'BLUE'
    break;
  case 'amarelo':
  cor = 'YELLOW'
  break
  case 'rosa':
  cor = '#FF00FF'
  break
  case 'branco':
  cor = 'WHITE'
  break
case 'roxo':
  cor = 'PURPLE'
  break
case 'verde':
  cor = 'GREEN'
  break
case 'vermelho':
  cor = 'RED'
  break
case 'preto':
  cor = 'BLACK'
  break
case 'laranja':
  cor = 'ORANGE'
  break
case 'cinza':
  cor = '#848484'
  break

					}
const desc_embed = interaction.options.getString('descricao')



const footer_embed = interaction.options.getString('footer')

const img_embed = interaction.options.getString('imagem_url')

const thumb_embed = interaction.options.getString('thumbnail_url')

const embed = new MessageEmbed()
.setTitle(titulo_embed)

if(cor_embed != 'null') {
  embed.setColor(cor)
}
if(desc_embed != 'null') {
  embed.setDescription(desc_embed)
}

if(footer_embed != 'null') {
  embed.setFooter(footer_embed)
}
if(img_embed != 'null') {
  embed.setImage(img_embed)
}
if(thumb_embed != 'null') {
  embed.setThumbnail(thumb_embed)
}
	
			
await interaction.deferReply();
		const em = await embed

if(!em) {
return interaction.reply('erro')						}
	
  await  interaction.editReply({ content: `${content_embed}`, embeds: [em]})
		}
		 }