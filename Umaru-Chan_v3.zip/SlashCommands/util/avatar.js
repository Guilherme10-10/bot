const Discord = require("discord.js")

module.exports = {
	
name: 'avatar',
description: '[🖼️] Mostra a foto de perfil de um membro.',
type: 'MENTIONABLE',
options: [
	{
		name: 'user',
		description: 'Mencione um usuário.',
		type: 'USER',
		required: 'true'
	}
],
	run: async(bot, interaction, args)=> { // Aqui definimos nosso client, 


	
let membro = interaction.options.getMember('user')
	//let member = `<@${membro}>`
 
 let img = membro.displayAvatarURL({ format: 'png', dynamic: true, size: 4096}) // puxa o avatar do membro
 
 const embed = new Discord.MessageEmbed() // cria a embed
 .setTitle(`🖼️ ${membro.user.tag}`)
 .setDescription(`**Clique [Aqui](${img}) para baixar o avatar.**`)
 .setURL(img)
 .setColor("ORANGE")
 .setImage(img)
 .setFooter(interaction.guild.name)
 .setTimestamp()
 
 interaction.reply({embeds: [embed]}) // envia a embed 
 }
}